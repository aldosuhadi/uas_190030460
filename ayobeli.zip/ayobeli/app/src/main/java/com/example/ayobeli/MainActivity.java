package com.example.ayobeli;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DownloadManager;
import android.os.Bundle;
import android.view.textclassifier.ConversationActions;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.ReferenceQueue;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private menuadapter menuadapter;
    private RecyclerView  RecyclerView;
    private ArrayList<menu> menus;
    int jumdata;
    private ReferenceQueue ReferenceQueue;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView=findViewById(R.id.rv_list);
        RecyclerView.setHasFixedSize(true);
        RecyclerView.setLayoutManager(new LinearLayoutManager( context: this));

        menus =new ArrayList<>();
        ReferenceQueue= Volley.newRequestQueue(context: this);
        parseJSON();

    }

    private void parseJSON() {
        String url=http://localhost:81/laptop/koneksi.php;
        JsonArrayRequest request = new JsonArrayRequest(DownloadManager.Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        jumdata = response.length();
                        try {
                            for (int i = 0; i < jumdata; i++) {
                                JSONObject data = response.getJSONObject(i);
                                String gambarmenu = data.getString(name:"gambar");
                                String namamenu = data.getString(name:"nama");
                                String hargamenu = data.getString(name:"harga");
                                menus.add(new menu(namamenu, hargamenu, gambarmenu));
                            }
                            menuadapter = new menuadapter(mcontext:MainActivity.this, menus);
                            RecyclerView.setAdapter(menuadapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }
        )
        RequestQueue.add(request);
    }
}
